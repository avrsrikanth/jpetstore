package org.mybatis.jpetstore.domain;

import java.io.Serializable;
import java.math.BigDecimal;

public class Calculate implements Serializable {

public void hello()
{
System.out.println("JPET Store Application");
System.out.println("Class name: Calculate.java");
System.out.println("Hello World");
System.out.println("Making a new Entry at Mon Jun 12 11:00:08 UTC 2017");
System.out.println("Mon Jun 12 11:00:08 UTC 2017");
System.out.println("Making a new Entry at Sat Jun 10 11:00:01 UTC 2017");
System.out.println("Sat Jun 10 11:00:01 UTC 2017");
System.out.println("Making a new Entry at Thu Jun  8 11:00:35 UTC 2017");
System.out.println("Thu Jun  8 11:00:35 UTC 2017");
System.out.println("Making a new Entry at Tue Jun  6 11:00:13 UTC 2017");
System.out.println("Tue Jun  6 11:00:13 UTC 2017");
System.out.println("Making a new Entry at Sun Jun  4 11:00:46 UTC 2017");
System.out.println("Sun Jun  4 11:00:46 UTC 2017");
System.out.println("Making a new Entry at Fri Jun  2 11:00:19 UTC 2017");
System.out.println("Fri Jun  2 11:00:19 UTC 2017");
System.out.println("Making a new Entry at Tue May 30 11:00:28 UTC 2017");
System.out.println("Tue May 30 11:00:28 UTC 2017");
System.out.println("Making a new Entry at Sun May 28 11:00:43 UTC 2017");
System.out.println("Sun May 28 11:00:43 UTC 2017");
System.out.println("Making a new Entry at Fri May 26 11:00:21 UTC 2017");
System.out.println("Fri May 26 11:00:21 UTC 2017");
System.out.println("Making a new Entry at Wed May 24 11:00:02 UTC 2017");
System.out.println("Wed May 24 11:00:02 UTC 2017");
System.out.println("Making a new Entry at Mon May 22 11:00:35 UTC 2017");
System.out.println("Mon May 22 11:00:35 UTC 2017");
System.out.println("Making a new Entry at Sat May 20 11:00:07 UTC 2017");
System.out.println("Sat May 20 11:00:07 UTC 2017");
System.out.println("Making a new Entry at Thu May 18 11:00:40 UTC 2017");
System.out.println("Thu May 18 11:00:40 UTC 2017");
System.out.println("Making a new Entry at Tue May 16 11:00:13 UTC 2017");
System.out.println("Tue May 16 11:00:13 UTC 2017");
System.out.println("Making a new Entry at Sun May 14 11:00:02 UTC 2017");
System.out.println("Sun May 14 11:00:02 UTC 2017");
System.out.println("Making a new Entry at Fri May 12 11:00:48 UTC 2017");
System.out.println("Fri May 12 11:00:48 UTC 2017");
System.out.println("Making a new Entry at Wed May 10 11:00:57 UTC 2017");
System.out.println("Wed May 10 11:00:57 UTC 2017");
System.out.println("Making a new Entry at Mon May  8 11:00:25 UTC 2017");
System.out.println("Mon May  8 11:00:25 UTC 2017");
System.out.println("Making a new Entry at Mon May  8 07:49:35 UTC 2017");
System.out.println("Mon May  8 07:49:35 UTC 2017");
System.out.println("Making a new Entry at Mon May  8 07:44:40 UTC 2017");
System.out.println("Mon May  8 07:44:40 UTC 2017");
System.out.println("Making a new Entry at Sat May  6 11:00:19 UTC 2017");
System.out.println("Sat May  6 11:00:19 UTC 2017");
System.out.println("Making a new Entry at Thu May  4 11:00:04 UTC 2017");
System.out.println("Thu May  4 11:00:04 UTC 2017");
System.out.println("Making a new Entry at Tue May  2 11:00:37 UTC 2017");
System.out.println("Tue May  2 11:00:37 UTC 2017");
System.out.println("Making a new Entry at Sun Apr 30 11:00:10 UTC 2017");
System.out.println("Sun Apr 30 11:00:10 UTC 2017");
System.out.println("Making a new Entry at Fri Apr 28 11:00:19 UTC 2017");
System.out.println("Fri Apr 28 11:00:19 UTC 2017");
System.out.println("Making a new Entry at Wed Apr 26 11:00:52 UTC 2017");
System.out.println("Wed Apr 26 11:00:52 UTC 2017");
System.out.println("Making a new Entry at Thu Apr 20 11:00:52 UTC 2017");
System.out.println("Thu Apr 20 11:00:52 UTC 2017");
System.out.println("Making a new Entry at Tue Apr 18 11:00:36 UTC 2017");
System.out.println("Tue Apr 18 11:00:36 UTC 2017");
System.out.println("Making a new Entry at Sun Apr 16 11:00:39 UTC 2017");
System.out.println("Sun Apr 16 11:00:39 UTC 2017");
System.out.println("Making a new Entry at Fri Apr 14 11:00:25 UTC 2017");
System.out.println("Fri Apr 14 11:00:25 UTC 2017");
System.out.println("Making a new Entry at Wed Apr 12 11:00:22 UTC 2017");
System.out.println("Wed Apr 12 11:00:22 UTC 2017");
System.out.println("Making a new Entry at Mon Apr 10 11:00:38 UTC 2017");
System.out.println("Mon Apr 10 11:00:38 UTC 2017");
System.out.println("Making a new Entry at Mon Apr 10 09:56:35 UTC 2017");
System.out.println("Mon Apr 10 09:56:35 UTC 2017");
System.out.println("Making a new Entry at Mon Apr 10 09:55:32 UTC 2017");
System.out.println("Mon Apr 10 09:55:32 UTC 2017");
System.out.println("Making a new Entry at Mon Apr 10 09:55:04 UTC 2017");
System.out.println("Mon Apr 10 09:55:04 UTC 2017");
System.out.println("Making a new Entry at Mon Apr 10 09:39:32 UTC 2017");
System.out.println("Mon Apr 10 09:39:32 UTC 2017");
System.out.println("Making a new Entry at Mon Apr 10 09:38:52 UTC 2017");
System.out.println("Mon Apr 10 09:38:52 UTC 2017");
System.out.println("Making a new Entry at Mon Apr 10 09:38:24 UTC 2017");
System.out.println("Mon Apr 10 09:38:24 UTC 2017");
System.out.println("Making a new Entry at Mon Apr 10 09:36:01 UTC 2017");
System.out.println("Mon Apr 10 09:36:01 UTC 2017");
System.out.println("Making a new Entry at Mon Apr 10 09:34:55 UTC 2017");
System.out.println("Mon Apr 10 09:34:55 UTC 2017");
System.out.println("Making a new Entry at Mon Apr 10 09:31:13 UTC 2017");
System.out.println("Mon Apr 10 09:31:13 UTC 2017");
System.out.println("Making a new Entry at Mon Apr 10 09:30:30 UTC 2017");
System.out.println("Mon Apr 10 09:30:30 UTC 2017");
System.out.println("Making a new Entry at Mon Apr 10 09:29:05 UTC 2017");
System.out.println("Mon Apr 10 09:29:05 UTC 2017");
System.out.println("Making a new Entry at Mon Apr 10 09:24:21 UTC 2017");
System.out.println("Mon Apr 10 09:24:21 UTC 2017");
System.out.println("Making a new Entry at Mon Apr 10 09:24:04 UTC 2017");
System.out.println("Mon Apr 10 09:24:04 UTC 2017");
System.out.println("Making a new Entry at Mon Apr 10 09:22:26 UTC 2017");
System.out.println("Mon Apr 10 09:22:26 UTC 2017");
System.out.println("Making a new Entry at Mon Apr 10 09:18:38 UTC 2017");
System.out.println("Mon Apr 10 09:18:38 UTC 2017");
System.out.println("Making a new Entry at Mon Apr 10 09:17:03 UTC 2017");
System.out.println("Mon Apr 10 09:17:03 UTC 2017");
System.out.println("Making a new Entry at Thu Mar  2 11:00:00 UTC 2017");
System.out.println("Thu Mar  2 11:00:00 UTC 2017");
System.out.println("Making a new Entry at Tue Feb 28 11:00:00 UTC 2017");
System.out.println("Tue Feb 28 11:00:00 UTC 2017");
System.out.println("Making a new Entry at Sun Feb 26 11:00:00 UTC 2017");
System.out.println("Sun Feb 26 11:00:00 UTC 2017");
System.out.println("Making a new Entry at Fri Feb 24 11:00:00 UTC 2017");
System.out.println("Fri Feb 24 11:00:00 UTC 2017");
System.out.println("Making a new Entry at Wed Feb 22 11:00:00 UTC 2017");
System.out.println("Wed Feb 22 11:00:00 UTC 2017");
System.out.println("Making a new Entry at Mon Feb 20 11:00:00 UTC 2017");
System.out.println("Mon Feb 20 11:00:00 UTC 2017");
System.out.println("Making a new Entry at Sat Feb 18 11:00:00 UTC 2017");
System.out.println("Sat Feb 18 11:00:00 UTC 2017");
System.out.println("Making a new Entry at Thu Feb 16 11:00:00 UTC 2017");
System.out.println("Thu Feb 16 11:00:00 UTC 2017");
System.out.println("Making a new Entry at Tue Feb 14 11:00:00 UTC 2017");
System.out.println("Tue Feb 14 11:00:00 UTC 2017");
System.out.println("Making a new Entry at Sun Feb 12 11:00:00 UTC 2017");
System.out.println("Sun Feb 12 11:00:00 UTC 2017");
System.out.println("Making a new Entry at Fri Feb 10 11:00:00 UTC 2017");
System.out.println("Fri Feb 10 11:00:00 UTC 2017");
System.out.println("Making a new Entry at Wed Feb  8 11:00:00 UTC 2017");
System.out.println("Wed Feb  8 11:00:00 UTC 2017");
System.out.println("Making a new Entry at Mon Feb  6 11:00:00 UTC 2017");
System.out.println("Mon Feb  6 11:00:00 UTC 2017");
System.out.println("Making a new Entry at Sat Feb  4 11:00:00 UTC 2017");
System.out.println("Sat Feb  4 11:00:00 UTC 2017");
System.out.println("Making a new Entry at Thu Feb  2 11:00:00 UTC 2017");
System.out.println("Thu Feb  2 11:00:00 UTC 2017");
System.out.println("Making a new Entry at Mon Jan 30 11:00:00 UTC 2017");
System.out.println("Mon Jan 30 11:00:00 UTC 2017");
System.out.println("Making a new Entry at Sat Jan 28 11:00:15 UTC 2017");
System.out.println("Sat Jan 28 11:00:15 UTC 2017");
System.out.println("Making a new Entry at Thu Jan 26 11:00:15 UTC 2017");
System.out.println("Thu Jan 26 11:00:15 UTC 2017");
System.out.println("Making a new Entry at Tue Jan 24 11:00:15 UTC 2017");
System.out.println("Tue Jan 24 11:00:15 UTC 2017");
System.out.println("Making a new Entry at Sun Jan 22 11:00:15 UTC 2017");
System.out.println("Sun Jan 22 11:00:15 UTC 2017");
System.out.println("Making a new Entry at Fri Jan 20 11:00:15 UTC 2017");
System.out.println("Fri Jan 20 11:00:15 UTC 2017");
System.out.println("Making a new Entry at Wed Jan 18 11:00:15 UTC 2017");
System.out.println("Wed Jan 18 11:00:15 UTC 2017");
System.out.println("Making a new Entry at Mon Jan 16 11:00:15 UTC 2017");
System.out.println("Mon Jan 16 11:00:15 UTC 2017");
System.out.println("Making a new Entry at Sat Jan 14 11:00:15 UTC 2017");
System.out.println("Sat Jan 14 11:00:15 UTC 2017");
System.out.println("Making a new Entry at Thu Jan 12 11:00:15 UTC 2017");
System.out.println("Thu Jan 12 11:00:15 UTC 2017");
System.out.println("Making a new Entry at Tue Jan 10 11:00:15 UTC 2017");
System.out.println("Tue Jan 10 11:00:15 UTC 2017");
System.out.println("Making a new Entry at Sun Jan  8 11:00:15 UTC 2017");
System.out.println("Sun Jan  8 11:00:15 UTC 2017");
System.out.println("Making a new Entry at Fri Jan  6 11:00:15 UTC 2017");
System.out.println("Fri Jan  6 11:00:15 UTC 2017");
System.out.println("Making a new Entry at Wed Jan  4 11:00:15 UTC 2017");
System.out.println("Wed Jan  4 11:00:15 UTC 2017");
System.out.println("Making a new Entry at Mon Jan  2 11:00:15 UTC 2017");
System.out.println("Mon Jan  2 11:00:15 UTC 2017");
System.out.println("Making a new Entry at Fri Dec 30 11:00:16 UTC 2016");
System.out.println("Fri Dec 30 11:00:16 UTC 2016");
System.out.println("Making a new Entry at Wed Dec 28 11:00:16 UTC 2016");
System.out.println("Wed Dec 28 11:00:16 UTC 2016");
System.out.println("Making a new Entry at Mon Dec 26 11:00:16 UTC 2016");
System.out.println("Mon Dec 26 11:00:16 UTC 2016");
System.out.println("Making a new Entry at Sat Dec 24 11:00:16 UTC 2016");
System.out.println("Sat Dec 24 11:00:16 UTC 2016");
System.out.println("Making a new Entry at Thu Dec 22 11:00:16 UTC 2016");
System.out.println("Thu Dec 22 11:00:16 UTC 2016");
System.out.println("Making a new Entry at Tue Dec 20 11:00:16 UTC 2016");
System.out.println("Tue Dec 20 11:00:16 UTC 2016");
System.out.println("Making a new Entry at Sun Dec 18 11:00:16 UTC 2016");
System.out.println("Sun Dec 18 11:00:16 UTC 2016");
System.out.println("Making a new Entry at Fri Dec 16 11:00:16 UTC 2016");
System.out.println("Fri Dec 16 11:00:16 UTC 2016");
System.out.println("Making a new Entry at Wed Dec 14 11:00:16 UTC 2016");
System.out.println("Wed Dec 14 11:00:16 UTC 2016");
System.out.println("Making a new Entry at Mon Dec 12 11:00:16 UTC 2016");
System.out.println("Mon Dec 12 11:00:16 UTC 2016");
System.out.println("Making a new Entry at Sat Dec 10 11:00:16 UTC 2016");
System.out.println("Sat Dec 10 11:00:16 UTC 2016");
System.out.println("Making a new Entry at Thu Dec  8 11:00:16 UTC 2016");
System.out.println("Thu Dec  8 11:00:16 UTC 2016");
System.out.println("Making a new Entry at Tue Dec  6 11:00:16 UTC 2016");
System.out.println("Tue Dec  6 11:00:16 UTC 2016");
System.out.println("Making a new Entry at Fri Dec  2 12:52:58 UTC 2016");
System.out.println("Fri Dec  2 12:52:58 UTC 2016");
}

}
//----------------------------------------------------
//Comment added on date:Fri Dec  2 09:45:31 UTC 2016
//Author: Andrew Woods, Apoorva Rao
//Description: Adding coments for documentation
//Project: JpetStore
//Tools used: Jenkins, SonarQube, Rundeck
//----------------------------------------------------
//Comment added on date:Fri Dec  2 09:55:14 UTC 2016
//Author: Andrew Woods, Apoorva Rao
//Description: Adding coments for documentation
//Project: JpetStore
//Tools used: Jenkins, SonarQube, Rundeck
//----------------------------------------------------
//----------------------------------------------------
//Comment added on date:Fri Dec  2 11:34:52 UTC 2016
//Author: Andrew Woods, Apoorva Rao
//Description: Adding coments for documentation
//Project: JpetStore
//Tools used: Jenkins, SonarQube, Rundeck
//----------------------------------------------------
//----------------------------------------------------
//Comment added on date:Fri Dec  2 11:35:25 UTC 2016
//Author: Andrew Woods, Apoorva Rao
//Description: Adding coments for documentation
//Project: JpetStore
//Tools used: Jenkins, SonarQube, Rundeck
//----------------------------------------------------
//----------------------------------------------------
//Comment added on date:Fri Dec  2 12:32:47 UTC 2016
//Author: Andrew Woods, Apoorva Rao
//Description: Adding coments for documentation
//Project: JpetStore
//Tools used: Jenkins, SonarQube, Rundeck
//----------------------------------------------------
//----------------------------------------------------
//Comment added on date:Mon Dec  5 05:39:41 UTC 2016
//Author: Andrew Woods, Apoorva Rao
//Description: Adding coments for documentation
//Project: JpetStore
//Tools used: Jenkins, SonarQube, Rundeck
//----------------------------------------------------
//----------------------------------------------------
//Comment added on date:Mon Dec  5 05:41:08 UTC 2016
//Author: Andrew Woods, Apoorva Rao
//Description: Adding coments for documentation
//Project: JpetStore
//Tools used: Jenkins, SonarQube, Rundeck
//----------------------------------------------------
//----------------------------------------------------
//Comment added on date:Mon Dec  5 05:41:14 UTC 2016
//Author: Andrew Woods, Apoorva Rao
//Description: Adding coments for documentation
//Project: JpetStore
//Tools used: Jenkins, SonarQube, Rundeck
//----------------------------------------------------
//----------------------------------------------------
//Comment added on date:Mon Dec  5 06:05:33 UTC 2016
//Author: Andrew Woods, Apoorva Rao
//Description: Adding coments for documentation
//Project: JpetStore
//Tools used: Jenkins, SonarQube, Rundeck
//----------------------------------------------------
//----------------------------------------------------
//Comment added on date:Mon Dec  5 11:00:16 UTC 2016
//Author: Andrew Woods, Apoorva Rao
//Description: Adding coments for documentation
//Project: JpetStore
//Tools used: Jenkins, SonarQube, Rundeck
//----------------------------------------------------
//----------------------------------------------------
//Comment added on date:Wed Dec  7 05:08:34 UTC 2016
//Author: Andrew Woods, Apoorva Rao
//Description: Adding coments for documentation
//Project: JpetStore
//Tools used: Jenkins, SonarQube, Rundeck
//----------------------------------------------------
//----------------------------------------------------
//Comment added on date:Wed Dec  7 11:00:16 UTC 2016
//Author: Andrew Woods, Apoorva Rao
//Description: Adding coments for documentation
//Project: JpetStore
//Tools used: Jenkins, SonarQube, Rundeck
//----------------------------------------------------
//----------------------------------------------------
//Comment added on date:Fri Dec  9 11:00:16 UTC 2016
//Author: Andrew Woods, Apoorva Rao
//Description: Adding coments for documentation
//Project: JpetStore
//Tools used: Jenkins, SonarQube, Rundeck
//----------------------------------------------------
//----------------------------------------------------
//Comment added on date:Sun Dec 11 11:00:16 UTC 2016
//Author: Andrew Woods, Apoorva Rao
//Description: Adding coments for documentation
//Project: JpetStore
//Tools used: Jenkins, SonarQube, Rundeck
//----------------------------------------------------
//----------------------------------------------------
//Comment added on date:Tue Dec 13 11:00:16 UTC 2016
//Author: Andrew Woods, Apoorva Rao
//Description: Adding coments for documentation
//Project: JpetStore
//Tools used: Jenkins, SonarQube, Rundeck
//----------------------------------------------------
//----------------------------------------------------
//Comment added on date:Thu Dec 15 11:00:16 UTC 2016
//Author: Andrew Woods, Apoorva Rao
//Description: Adding coments for documentation
//Project: JpetStore
//Tools used: Jenkins, SonarQube, Rundeck
//----------------------------------------------------
//----------------------------------------------------
//Comment added on date:Sat Dec 17 11:00:16 UTC 2016
//Author: Andrew Woods, Apoorva Rao
//Description: Adding coments for documentation
//Project: JpetStore
//Tools used: Jenkins, SonarQube, Rundeck
//----------------------------------------------------
//----------------------------------------------------
//Comment added on date:Mon Dec 19 11:00:16 UTC 2016
//Author: Andrew Woods, Apoorva Rao
//Description: Adding coments for documentation
//Project: JpetStore
//Tools used: Jenkins, SonarQube, Rundeck
//----------------------------------------------------
//----------------------------------------------------
//Comment added on date:Wed Dec 21 11:00:16 UTC 2016
//Author: Andrew Woods, Apoorva Rao
//Description: Adding coments for documentation
//Project: JpetStore
//Tools used: Jenkins, SonarQube, Rundeck
//----------------------------------------------------
//----------------------------------------------------
//Comment added on date:Fri Dec 23 11:00:16 UTC 2016
//Author: Andrew Woods, Apoorva Rao
//Description: Adding coments for documentation
//Project: JpetStore
//Tools used: Jenkins, SonarQube, Rundeck
//----------------------------------------------------
//----------------------------------------------------
//Comment added on date:Sun Dec 25 11:00:16 UTC 2016
//Author: Andrew Woods, Apoorva Rao
//Description: Adding coments for documentation
//Project: JpetStore
//Tools used: Jenkins, SonarQube, Rundeck
//----------------------------------------------------
//----------------------------------------------------
//Comment added on date:Tue Dec 27 11:00:16 UTC 2016
//Author: Andrew Woods, Apoorva Rao
//Description: Adding coments for documentation
//Project: JpetStore
//Tools used: Jenkins, SonarQube, Rundeck
//----------------------------------------------------
//----------------------------------------------------
//Comment added on date:Thu Dec 29 11:00:16 UTC 2016
//Author: Andrew Woods, Apoorva Rao
//Description: Adding coments for documentation
//Project: JpetStore
//Tools used: Jenkins, SonarQube, Rundeck
//----------------------------------------------------
//----------------------------------------------------
//Comment added on date:Sat Dec 31 11:00:16 UTC 2016
//Author: Andrew Woods, Apoorva Rao
//Description: Adding coments for documentation
//Project: JpetStore
//Tools used: Jenkins, SonarQube, Rundeck
//----------------------------------------------------
//----------------------------------------------------
//Comment added on date:Sun Jan  1 11:00:15 UTC 2017
//Author: Andrew Woods, Apoorva Rao
//Description: Adding coments for documentation
//Project: JpetStore
//Tools used: Jenkins, SonarQube, Rundeck
//----------------------------------------------------
//----------------------------------------------------
//Comment added on date:Tue Jan  3 11:00:15 UTC 2017
//Author: Andrew Woods, Apoorva Rao
//Description: Adding coments for documentation
//Project: JpetStore
//Tools used: Jenkins, SonarQube, Rundeck
//----------------------------------------------------
//----------------------------------------------------
//Comment added on date:Thu Jan  5 11:00:15 UTC 2017
//Author: Andrew Woods, Apoorva Rao
//Description: Adding coments for documentation
//Project: JpetStore
//Tools used: Jenkins, SonarQube, Rundeck
//----------------------------------------------------
//----------------------------------------------------
//Comment added on date:Sat Jan  7 11:00:15 UTC 2017
//Author: Andrew Woods, Apoorva Rao
//Description: Adding coments for documentation
//Project: JpetStore
//Tools used: Jenkins, SonarQube, Rundeck
//----------------------------------------------------
//----------------------------------------------------
//Comment added on date:Mon Jan  9 11:00:15 UTC 2017
//Author: Andrew Woods, Apoorva Rao
//Description: Adding coments for documentation
//Project: JpetStore
//Tools used: Jenkins, SonarQube, Rundeck
//----------------------------------------------------
//----------------------------------------------------
//Comment added on date:Wed Jan 11 11:00:15 UTC 2017
//Author: Andrew Woods, Apoorva Rao
//Description: Adding coments for documentation
//Project: JpetStore
//Tools used: Jenkins, SonarQube, Rundeck
//----------------------------------------------------
//----------------------------------------------------
//Comment added on date:Fri Jan 13 11:00:15 UTC 2017
//Author: Andrew Woods, Apoorva Rao
//Description: Adding coments for documentation
//Project: JpetStore
//Tools used: Jenkins, SonarQube, Rundeck
//----------------------------------------------------
//----------------------------------------------------
//Comment added on date:Sun Jan 15 11:00:15 UTC 2017
//Author: Andrew Woods, Apoorva Rao
//Description: Adding coments for documentation
//Project: JpetStore
//Tools used: Jenkins, SonarQube, Rundeck
//----------------------------------------------------
//----------------------------------------------------
//Comment added on date:Tue Jan 17 11:00:15 UTC 2017
//Author: Andrew Woods, Apoorva Rao
//Description: Adding coments for documentation
//Project: JpetStore
//Tools used: Jenkins, SonarQube, Rundeck
//----------------------------------------------------
//----------------------------------------------------
//Comment added on date:Thu Jan 19 11:00:15 UTC 2017
//Author: Andrew Woods, Apoorva Rao
//Description: Adding coments for documentation
//Project: JpetStore
//Tools used: Jenkins, SonarQube, Rundeck
//----------------------------------------------------
//----------------------------------------------------
//Comment added on date:Sat Jan 21 11:00:15 UTC 2017
//Author: Andrew Woods, Apoorva Rao
//Description: Adding coments for documentation
//Project: JpetStore
//Tools used: Jenkins, SonarQube, Rundeck
//----------------------------------------------------
//----------------------------------------------------
//Comment added on date:Mon Jan 23 11:00:15 UTC 2017
//Author: Andrew Woods, Apoorva Rao
//Description: Adding coments for documentation
//Project: JpetStore
//Tools used: Jenkins, SonarQube, Rundeck
//----------------------------------------------------
//----------------------------------------------------
//Comment added on date:Wed Jan 25 11:00:15 UTC 2017
//Author: Andrew Woods, Apoorva Rao
//Description: Adding coments for documentation
//Project: JpetStore
//Tools used: Jenkins, SonarQube, Rundeck
//----------------------------------------------------
//----------------------------------------------------
//Comment added on date:Fri Jan 27 11:00:15 UTC 2017
//Author: Andrew Woods, Apoorva Rao
//Description: Adding coments for documentation
//Project: JpetStore
//Tools used: Jenkins, SonarQube, Rundeck
//----------------------------------------------------
//----------------------------------------------------
//Comment added on date:Sun Jan 29 11:00:15 UTC 2017
//Author: Andrew Woods, Apoorva Rao
//Description: Adding coments for documentation
//Project: JpetStore
//Tools used: Jenkins, SonarQube, Rundeck
//----------------------------------------------------
//----------------------------------------------------
//Comment added on date:Tue Jan 31 11:00:00 UTC 2017
//Author: Andrew Woods, Apoorva Rao
//Description: Adding coments for documentation
//Project: JpetStore
//Tools used: Jenkins, SonarQube, Rundeck
//----------------------------------------------------
//----------------------------------------------------
//Comment added on date:Wed Feb  1 11:00:00 UTC 2017
//Author: Andrew Woods, Apoorva Rao
//Description: Adding coments for documentation
//Project: JpetStore
//Tools used: Jenkins, SonarQube, Rundeck
//----------------------------------------------------
//----------------------------------------------------
//Comment added on date:Fri Feb  3 11:00:00 UTC 2017
//Author: Andrew Woods, Apoorva Rao
//Description: Adding coments for documentation
//Project: JpetStore
//Tools used: Jenkins, SonarQube, Rundeck
//----------------------------------------------------
//----------------------------------------------------
//Comment added on date:Sun Feb  5 11:00:00 UTC 2017
//Author: Andrew Woods, Apoorva Rao
//Description: Adding coments for documentation
//Project: JpetStore
//Tools used: Jenkins, SonarQube, Rundeck
//----------------------------------------------------
//----------------------------------------------------
//Comment added on date:Tue Feb  7 11:00:00 UTC 2017
//Author: Andrew Woods, Apoorva Rao
//Description: Adding coments for documentation
//Project: JpetStore
//Tools used: Jenkins, SonarQube, Rundeck
//----------------------------------------------------
//----------------------------------------------------
//Comment added on date:Thu Feb  9 11:00:00 UTC 2017
//Author: Andrew Woods, Apoorva Rao
//Description: Adding coments for documentation
//Project: JpetStore
//Tools used: Jenkins, SonarQube, Rundeck
//----------------------------------------------------
//----------------------------------------------------
//Comment added on date:Sat Feb 11 11:00:00 UTC 2017
//Author: Andrew Woods, Apoorva Rao
//Description: Adding coments for documentation
//Project: JpetStore
//Tools used: Jenkins, SonarQube, Rundeck
//----------------------------------------------------
//----------------------------------------------------
//Comment added on date:Mon Feb 13 11:00:00 UTC 2017
//Author: Andrew Woods, Apoorva Rao
//Description: Adding coments for documentation
//Project: JpetStore
//Tools used: Jenkins, SonarQube, Rundeck
//----------------------------------------------------
//----------------------------------------------------
//Comment added on date:Wed Feb 15 11:00:00 UTC 2017
//Author: Andrew Woods, Apoorva Rao
//Description: Adding coments for documentation
//Project: JpetStore
//Tools used: Jenkins, SonarQube, Rundeck
//----------------------------------------------------
//----------------------------------------------------
//Comment added on date:Fri Feb 17 11:00:00 UTC 2017
//Author: Andrew Woods, Apoorva Rao
//Description: Adding coments for documentation
//Project: JpetStore
//Tools used: Jenkins, SonarQube, Rundeck
//----------------------------------------------------
//----------------------------------------------------
//Comment added on date:Sun Feb 19 11:00:00 UTC 2017
//Author: Andrew Woods, Apoorva Rao
//Description: Adding coments for documentation
//Project: JpetStore
//Tools used: Jenkins, SonarQube, Rundeck
//----------------------------------------------------
//----------------------------------------------------
//Comment added on date:Tue Feb 21 11:00:00 UTC 2017
//Author: Andrew Woods, Apoorva Rao
//Description: Adding coments for documentation
//Project: JpetStore
//Tools used: Jenkins, SonarQube, Rundeck
//----------------------------------------------------
//----------------------------------------------------
//Comment added on date:Thu Feb 23 11:00:00 UTC 2017
//Author: Andrew Woods, Apoorva Rao
//Description: Adding coments for documentation
//Project: JpetStore
//Tools used: Jenkins, SonarQube, Rundeck
//----------------------------------------------------
//----------------------------------------------------
//Comment added on date:Sat Feb 25 11:00:00 UTC 2017
//Author: Andrew Woods, Apoorva Rao
//Description: Adding coments for documentation
//Project: JpetStore
//Tools used: Jenkins, SonarQube, Rundeck
//----------------------------------------------------
//----------------------------------------------------
//Comment added on date:Mon Feb 27 11:00:00 UTC 2017
//Author: Andrew Woods, Apoorva Rao
//Description: Adding coments for documentation
//Project: JpetStore
//Tools used: Jenkins, SonarQube, Rundeck
//----------------------------------------------------
//----------------------------------------------------
//Comment added on date:Wed Mar  1 11:00:00 UTC 2017
//Author: Andrew Woods, Apoorva Rao
//Description: Adding coments for documentation
//Project: JpetStore
//Tools used: Jenkins, SonarQube, Rundeck
//----------------------------------------------------
//----------------------------------------------------
//Comment added on date:Tue Apr 11 06:09:20 UTC 2017
//Author: Andrew Woods, Apoorva Rao
//Description: Adding coments for documentation
//Project: JpetStore
//Tools used: Jenkins, SonarQube, Rundeck
//----------------------------------------------------
//----------------------------------------------------
//Comment added on date:Tue Apr 11 06:09:28 UTC 2017
//Author: Andrew Woods, Apoorva Rao
//Description: Adding coments for documentation
//Project: JpetStore
//Tools used: Jenkins, SonarQube, Rundeck
//----------------------------------------------------
//----------------------------------------------------
//Comment added on date:Tue Apr 11 06:09:34 UTC 2017
//Author: Andrew Woods, Apoorva Rao
//Description: Adding coments for documentation
//Project: JpetStore
//Tools used: Jenkins, SonarQube, Rundeck
//----------------------------------------------------
//----------------------------------------------------
//Comment added on date:Tue Apr 11 06:12:12 UTC 2017
//Author: Andrew Woods, Apoorva Rao
//Description: Adding coments for documentation
//Project: JpetStore
//Tools used: Jenkins, SonarQube, Rundeck
//----------------------------------------------------
//----------------------------------------------------
//Comment added on date:Tue Apr 11 06:15:00 UTC 2017
//Author: Andrew Woods, Apoorva Rao
//Description: Adding coments for documentation
//Project: JpetStore
//Tools used: Jenkins, SonarQube, Rundeck
//----------------------------------------------------
//----------------------------------------------------
//Comment added on date:Tue Apr 11 11:00:55 UTC 2017
//Author: Andrew Woods, Apoorva Rao
//Description: Adding coments for documentation
//Project: JpetStore
//Tools used: Jenkins, SonarQube, Rundeck
//----------------------------------------------------
//----------------------------------------------------
//Comment added on date:Thu Apr 13 11:00:41 UTC 2017
//Author: Andrew Woods, Apoorva Rao
//Description: Adding coments for documentation
//Project: JpetStore
//Tools used: Jenkins, SonarQube, Rundeck
//----------------------------------------------------
//----------------------------------------------------
//Comment added on date:Sat Apr 15 11:00:05 UTC 2017
//Author: Andrew Woods, Apoorva Rao
//Description: Adding coments for documentation
//Project: JpetStore
//Tools used: Jenkins, SonarQube, Rundeck
//----------------------------------------------------
//----------------------------------------------------
//Comment added on date:Mon Apr 17 11:00:08 UTC 2017
//Author: Andrew Woods, Apoorva Rao
//Description: Adding coments for documentation
//Project: JpetStore
//Tools used: Jenkins, SonarQube, Rundeck
//----------------------------------------------------
//----------------------------------------------------
//Comment added on date:Wed Apr 19 11:00:53 UTC 2017
//Author: Andrew Woods, Apoorva Rao
//Description: Adding coments for documentation
//Project: JpetStore
//Tools used: Jenkins, SonarQube, Rundeck
//----------------------------------------------------
//----------------------------------------------------
//Comment added on date:Fri Apr 21 11:00:36 UTC 2017
//Author: Andrew Woods, Apoorva Rao
//Description: Adding coments for documentation
//Project: JpetStore
//Tools used: Jenkins, SonarQube, Rundeck
//----------------------------------------------------
//----------------------------------------------------
//Comment added on date:Sun Apr 23 11:00:00 UTC 2017
//Author: Andrew Woods, Apoorva Rao
//Description: Adding coments for documentation
//Project: JpetStore
//Tools used: Jenkins, SonarQube, Rundeck
//----------------------------------------------------
//----------------------------------------------------
//Comment added on date:Tue Apr 25 11:00:09 UTC 2017
//Author: Andrew Woods, Apoorva Rao
//Description: Adding coments for documentation
//Project: JpetStore
//Tools used: Jenkins, SonarQube, Rundeck
//----------------------------------------------------
//----------------------------------------------------
//Comment added on date:Thu Apr 27 11:00:36 UTC 2017
//Author: Andrew Woods, Apoorva Rao
//Description: Adding coments for documentation
//Project: JpetStore
//Tools used: Jenkins, SonarQube, Rundeck
//----------------------------------------------------
//----------------------------------------------------
//Comment added on date:Sat Apr 29 11:00:26 UTC 2017
//Author: Andrew Woods, Apoorva Rao
//Description: Adding coments for documentation
//Project: JpetStore
//Tools used: Jenkins, SonarQube, Rundeck
//----------------------------------------------------
//----------------------------------------------------
//Comment added on date:Mon May  1 11:00:54 UTC 2017
//Author: Andrew Woods, Apoorva Rao
//Description: Adding coments for documentation
//Project: JpetStore
//Tools used: Jenkins, SonarQube, Rundeck
//----------------------------------------------------
//----------------------------------------------------
//Comment added on date:Wed May  3 11:00:21 UTC 2017
//Author: Andrew Woods, Apoorva Rao
//Description: Adding coments for documentation
//Project: JpetStore
//Tools used: Jenkins, SonarQube, Rundeck
//----------------------------------------------------
//----------------------------------------------------
//Comment added on date:Fri May  5 11:00:36 UTC 2017
//Author: Andrew Woods, Apoorva Rao
//Description: Adding coments for documentation
//Project: JpetStore
//Tools used: Jenkins, SonarQube, Rundeck
//----------------------------------------------------
//----------------------------------------------------
//Comment added on date:Sun May  7 11:00:49 UTC 2017
//Author: Andrew Woods, Apoorva Rao
//Description: Adding coments for documentation
//Project: JpetStore
//Tools used: Jenkins, SonarQube, Rundeck
//----------------------------------------------------
//----------------------------------------------------
//Comment added on date:Tue May  9 11:00:15 UTC 2017
//Author: Andrew Woods, Apoorva Rao
//Description: Adding coments for documentation
//Project: JpetStore
//Tools used: Jenkins, SonarQube, Rundeck
//----------------------------------------------------
//----------------------------------------------------
//Comment added on date:Thu May 11 11:00:17 UTC 2017
//Author: Andrew Woods, Apoorva Rao
//Description: Adding coments for documentation
//Project: JpetStore
//Tools used: Jenkins, SonarQube, Rundeck
//----------------------------------------------------
//----------------------------------------------------
//Comment added on date:Sat May 13 11:00:19 UTC 2017
//Author: Andrew Woods, Apoorva Rao
//Description: Adding coments for documentation
//Project: JpetStore
//Tools used: Jenkins, SonarQube, Rundeck
//----------------------------------------------------
//----------------------------------------------------
//Comment added on date:Mon May 15 11:00:46 UTC 2017
//Author: Andrew Woods, Apoorva Rao
//Description: Adding coments for documentation
//Project: JpetStore
//Tools used: Jenkins, SonarQube, Rundeck
//----------------------------------------------------
//----------------------------------------------------
//Comment added on date:Wed May 17 11:00:56 UTC 2017
//Author: Andrew Woods, Apoorva Rao
//Description: Adding coments for documentation
//Project: JpetStore
//Tools used: Jenkins, SonarQube, Rundeck
//----------------------------------------------------
//----------------------------------------------------
//Comment added on date:Fri May 19 11:00:23 UTC 2017
//Author: Andrew Woods, Apoorva Rao
//Description: Adding coments for documentation
//Project: JpetStore
//Tools used: Jenkins, SonarQube, Rundeck
//----------------------------------------------------
//----------------------------------------------------
//Comment added on date:Sun May 21 11:00:50 UTC 2017
//Author: Andrew Woods, Apoorva Rao
//Description: Adding coments for documentation
//Project: JpetStore
//Tools used: Jenkins, SonarQube, Rundeck
//----------------------------------------------------
//----------------------------------------------------
//Comment added on date:Tue May 23 11:00:17 UTC 2017
//Author: Andrew Woods, Apoorva Rao
//Description: Adding coments for documentation
//Project: JpetStore
//Tools used: Jenkins, SonarQube, Rundeck
//----------------------------------------------------
//----------------------------------------------------
//Comment added on date:Thu May 25 11:00:44 UTC 2017
//Author: Andrew Woods, Apoorva Rao
//Description: Adding coments for documentation
//Project: JpetStore
//Tools used: Jenkins, SonarQube, Rundeck
//----------------------------------------------------
//----------------------------------------------------
//Comment added on date:Sat May 27 11:01:00 UTC 2017
//Author: Andrew Woods, Apoorva Rao
//Description: Adding coments for documentation
//Project: JpetStore
//Tools used: Jenkins, SonarQube, Rundeck
//----------------------------------------------------
//----------------------------------------------------
//Comment added on date:Mon May 29 11:00:27 UTC 2017
//Author: Andrew Woods, Apoorva Rao
//Description: Adding coments for documentation
//Project: JpetStore
//Tools used: Jenkins, SonarQube, Rundeck
//----------------------------------------------------
//----------------------------------------------------
//Comment added on date:Wed May 31 11:00:52 UTC 2017
//Author: Andrew Woods, Apoorva Rao
//Description: Adding coments for documentation
//Project: JpetStore
//Tools used: Jenkins, SonarQube, Rundeck
//----------------------------------------------------
//----------------------------------------------------
//Comment added on date:Thu Jun  1 11:00:35 UTC 2017
//Author: Andrew Woods, Apoorva Rao
//Description: Adding coments for documentation
//Project: JpetStore
//Tools used: Jenkins, SonarQube, Rundeck
//----------------------------------------------------
//----------------------------------------------------
//Comment added on date:Sat Jun  3 11:00:02 UTC 2017
//Author: Andrew Woods, Apoorva Rao
//Description: Adding coments for documentation
//Project: JpetStore
//Tools used: Jenkins, SonarQube, Rundeck
//----------------------------------------------------
//----------------------------------------------------
//Comment added on date:Mon Jun  5 11:00:29 UTC 2017
//Author: Andrew Woods, Apoorva Rao
//Description: Adding coments for documentation
//Project: JpetStore
//Tools used: Jenkins, SonarQube, Rundeck
//----------------------------------------------------
//----------------------------------------------------
//Comment added on date:Wed Jun  7 11:00:57 UTC 2017
//Author: Andrew Woods, Apoorva Rao
//Description: Adding coments for documentation
//Project: JpetStore
//Tools used: Jenkins, SonarQube, Rundeck
//----------------------------------------------------
//----------------------------------------------------
//Comment added on date:Fri Jun  9 11:00:19 UTC 2017
//Author: Andrew Woods, Apoorva Rao
//Description: Adding coments for documentation
//Project: JpetStore
//Tools used: Jenkins, SonarQube, Rundeck
//----------------------------------------------------
//----------------------------------------------------
//Comment added on date:Sun Jun 11 11:00:51 UTC 2017
//Author: Andrew Woods, Apoorva Rao
//Description: Adding coments for documentation
//Project: JpetStore
//Tools used: Jenkins, SonarQube, Rundeck
//----------------------------------------------------
